from django.apps import AppConfig


class SubCategoriesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sub_categories'
