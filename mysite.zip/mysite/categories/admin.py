from django.contrib import admin
from .models import Categories
# Register your models here.
admin.site.register(Categories)
